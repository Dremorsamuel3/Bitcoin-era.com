"use client"
import Navigation from "@/components/navigation"
import Hero from "@/components/hero"
import Features from "@/components/features"
import HowItWorks from "@/components/how-it-works"
import TraderProfile from "@/components/trader-profile"
import Trading from "@/components/trading"
import DashboardShowcase from "@/components/dashboard-showcase"
import WealthSection from "@/components/wealth-section"
import LuxuryShowcase from "@/components/luxury-showcase"
import Testimonials from "@/components/testimonials"
import Contact from "@/components/contact"
import Footer from "@/components/footer"

export default function Home() {
  return (
    <main className="w-full">
      <Navigation />
      <Hero />
      <Features />
      <HowItWorks />
      <TraderProfile />
      <Trading />
      <DashboardShowcase />
      <WealthSection />
      <LuxuryShowcase />
      <Testimonials />
      <Contact />
      <Footer />
    </main>
  )
}
