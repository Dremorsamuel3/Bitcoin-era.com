function togglePassword() {
    const passwordInput = document.getElementById('passwordInput');
    const eyeIcon = document.getElementById('eyeIcon');
    
    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        eyeIcon.classList.remove('fa-eye');
        eyeIcon.classList.add('fa-eye-slash');
    } else {
        passwordInput.type = 'password';
        eyeIcon.classList.remove('fa-eye-slash');
        eyeIcon.classList.add('fa-eye');
    }
}

function updateCountdown() {
    const now = new Date();
    const deadline = new Date('2025-12-15T23:59:59');
    const diff = deadline - now;

    if (diff > 0) {
        const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
        const countdownElement = document.getElementById('countdown');
        if (countdownElement) {
            countdownElement.textContent = String(hours).padStart(2, '0') + ':' + String(minutes).padStart(2, '0');
        }
    }
}

// Update countdown every second
setInterval(updateCountdown, 1000);
updateCountdown();

document.addEventListener('DOMContentLoaded', function() {
    const registrationForm = document.getElementById('registrationForm');
    
    if (registrationForm) {
        registrationForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get form data
            const formData = new FormData(registrationForm);
            const data = {
                firstName: formData.get('firstName'),
                lastName: formData.get('lastName'),
                email: formData.get('email'),
                password: formData.get('password'),
                country: formData.get('country'),
                phoneCode: formData.get('phoneCode'),
                phone: formData.get('phone')
            };
            
            // Validate form
            if (validateRegistrationForm(data)) {
                console.log('[v0] Registration submitted:', data);
                
                // Show success message
                document.getElementById('registrationForm').classList.add('d-none');
                const successMsg = document.getElementById('successMessage');
                document.getElementById('confirmEmail').textContent = data.email;
                successMsg.classList.remove('d-none');
                
                // Reset after 3 seconds
                setTimeout(function() {
                    registrationForm.reset();
                    successMsg.classList.add('d-none');
                    document.getElementById('registrationForm').classList.remove('d-none');
                }, 3000);
            }
        });
    }
});

function validateRegistrationForm(data) {
    const errors = {};
    
    if (!data.firstName.trim()) {
        errors.firstName = 'First name is required';
    }
    if (!data.lastName.trim()) {
        errors.lastName = 'Last name is required';
    }
    if (!data.email.trim()) {
        errors.email = 'Email is required';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
        errors.email = 'Invalid email format';
    }
    if (!data.password) {
        errors.password = 'Password is required';
    } else if (data.password.length < 6) {
        errors.password = 'Password must be at least 6 characters';
    }
    if (!data.country.trim()) {
        errors.country = 'Country is required';
    }
    if (!data.phone.trim()) {
        errors.phone = 'Phone number is required';
    }
    
    // Display errors
    let hasErrors = false;
    for (const field in errors) {
        hasErrors = true;
        const errorElement = document.getElementById(field + '-error');
        if (errorElement) {
            errorElement.textContent = errors[field];
            errorElement.classList.remove('d-none');
        }
    }
    
    // Clear previous errors
    document.querySelectorAll('small[id$="-error"]').forEach(el => {
        if (!el.textContent) {
            el.classList.add('d-none');
        }
    });
    
    return !hasErrors;
}

document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('input, select').forEach(field => {
        field.addEventListener('focus', function() {
            const errorElement = document.getElementById(this.name + '-error');
            if (errorElement) {
                errorElement.classList.add('d-none');
                errorElement.textContent = '';
            }
        });
    });
});

document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});
