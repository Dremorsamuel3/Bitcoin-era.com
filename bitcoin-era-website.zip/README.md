# Bitcoin Era - Automated Trading Platform Website

*Automatically synced with your [v0.app](https://v0.app) deployments*

[![Deployed on Vercel](https://img.shields.io/badge/Deployed%20on-Vercel-black?style=for-the-badge&logo=vercel)](https://vercel.com/dremorsamuel4-6455s-projects/v0-bitcoin-era-website)
[![Built with v0](https://img.shields.io/badge/Built%20with-v0.app-black?style=for-the-badge)](https://v0.app/chat/g6V1YjOvRx5)

## Overview

A professional, fully responsive HTML/CSS/Bootstrap/JavaScript landing page for Bitcoin Era - an automated AI-powered trading platform for Forex, Stocks, Crypto, Indices, and Metals. This repository stays in sync with your v0.app deployments.

## Features

✨ **Modern Responsive Design**
- Fully responsive Bootstrap 5 layout
- Mobile-first approach
- Works seamlessly on all devices

🤖 **AI Trading Platform**
- Automated trading capabilities
- Multi-market support (Forex, Stocks, Crypto, Indices, Metals)
- 24/7 trading automation
- Advanced risk management

📋 **Functional Registration Form**
- Real-time form validation
- Error messages and feedback
- Secure password input with toggle
- Success confirmation message
- Country and phone code selection

⏰ **Live Countdown Timer**
- Displays registration deadline (December 15, 2025)
- Updates every second
- Creates urgency for conversions

👥 **Testimonials Section**
- Real Ugandan trader success stories
- Earnings displayed in UGX currency
- Professional trader profiles (6 traders)

📞 **Contact & Support**
- Multiple contact methods
- 24/7 customer support
- Professional footer with links

## Project Structure

\`\`\`
bitcoin-era-website/
├── index.html              # Main landing page
├── css/
│   └── styles.css         # Custom styling & Bootstrap overrides
├── js/
│   └── script.js          # Form validation & interactivity
├── images/                # All project images
│   ├── ai-robot-trading.jpeg
│   ├── bitcoin-era-platform.png
│   ├── trading-chart.webp
│   ├── gold-bitcoin-trading.jpg
│   ├── luxury-car-concept.jpeg
│   ├── electric-vehicle.jpeg
│   └── ... (more images)
├── README.md              # This file
└── LICENSE                # MIT License
\`\`\`

## Live Deployment

Your project is live at:

**[https://vercel.com/dremorsamuel4-6455s-projects/v0-bitcoin-era-website](https://vercel.com/dremorsamuel4-6455s-projects/v0-bitcoin-era-website)**

## Installation & Setup

### Option 1: Direct File Usage
1. Download or clone this repository
2. Open \`index.html\` in your web browser
3. The site will load with all features enabled

### Option 2: Local Server (Recommended)
\`\`\`bash
# Using Python 3
python -m http.server 8000

# Using Node.js (with http-server)
npx http-server

# Using PHP
php -S localhost:8000
\`\`\`
Then visit \`http://localhost:8000\` in your browser.

## How It Works

1. Create and modify your project using [v0.app](https://v0.app)
2. Deploy your chats from the v0 interface
3. Changes are automatically pushed to this repository
4. Vercel deploys the latest version from this repository

## Form Validation

The registration form includes:
- ✓ First Name validation
- ✓ Last Name validation
- ✓ Email format validation
- ✓ Password length validation (minimum 6 characters)
- ✓ Password visibility toggle
- ✓ Country selection
- ✓ Phone number with country code
- ✓ Real-time error messages
- ✓ Success notification

## Customization

### Modify Company Information
Edit in \`index.html\`:
- Company name and logo
- Contact email: support@bitcoinera.com
- Phone number: +1-800-BITCOIN
- Social media links in footer

### Change Colors
Edit in \`css/styles.css\`:
\`\`\`css
:root {
    --primary-blue: #1e3a8a;
    --primary-purple: #581c87;
    --warning-yellow: #fbbf24;
}
\`\`\`

### Update Testimonials
Add more trader testimonials in \`index.html\`:
\`\`\`html
<div class="col-md-4">
    <div class="card bg-dark border-warning text-white h-100">
        <div class="card-body">
            <h5 class="card-title fw-bold">Trader Name</h5>
            <p class="text-warning fw-bold">UGX Amount</p>
            <p class="card-text text-light">"Testimonial text here"</p>
        </div>
    </div>
</div>
\`\`\`

## Technologies Used

- **HTML5** - Semantic markup
- **CSS3** - Custom styling and animations
- **Bootstrap 5** - Responsive framework
- **JavaScript (Vanilla)** - Form validation and interactivity
- **Font Awesome** - Icons
- **CDN Resources** - Fast loading from cloud

## Browser Compatibility

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)
- Mobile browsers (iOS Safari, Chrome Mobile)

## Deployment Options

### GitHub Pages
\`\`\`bash
1. Push to GitHub
2. Go to repository Settings
3. Enable GitHub Pages
4. Select main branch
5. Your site will be live
\`\`\`

### Netlify
1. Drag and drop the folder to Netlify
2. Or connect your GitHub repository
3. Automatic deploys on push

### Vercel
1. Connect your GitHub repository
2. Deploy automatically

## Build Your App

Continue building your app on:

**[https://v0.app/chat/g6V1YjOvRx5](https://v0.app/chat/g6V1YjOvRx5)**

## Support

For questions about the website:
- Email: support@bitcoinera.com
- Phone: +1-800-BITCOIN
- Hours: 24/7 Customer Support

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Version History

**v1.0.0** (2025-11-16)
- Initial release
- Complete landing page with all features
- Responsive design
- Form validation
- Testimonials section
- Countdown timer
- All images included

---

**Built with v0.app** - AI-powered web development
