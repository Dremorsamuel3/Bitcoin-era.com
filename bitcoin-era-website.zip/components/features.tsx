"use client"

export default function Features() {
  const features = [
    {
      icon: "📊",
      title: "Forex Trading",
      description: "Trade major currency pairs with advanced algorithmic precision and real-time market analysis.",
    },
    {
      icon: "📈",
      title: "Stock Market",
      description: "Access automated trading strategies for global stock exchanges and emerging markets.",
    },
    {
      icon: "⚡",
      title: "Crypto Trading",
      description: "Leverage Bitcoin, Ethereum, and 500+ altcoins with 24/7 automated trading capabilities.",
    },
    {
      icon: "🏅",
      title: "Indices Trading",
      description: "Trade major indices like S&P 500, DAX, and Nikkei with algorithmic precision.",
    },
    {
      icon: "💎",
      title: "Metals Trading",
      description: "Automate Gold, Silver, and other precious metals trading with real-time market data.",
    },
    {
      icon: "🤖",
      title: "AI Robot Trading",
      description: "Our advanced AI analyzes millions of data points to execute profitable trades 24/7.",
    },
  ]

  return (
    <section id="features" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-blue-900 mb-4 text-balance">
            Trading in Multiple Markets
          </h2>
          <p className="text-xl text-gray-600 text-balance">
            Our AI-powered robots can trade simultaneously across all major financial markets
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div
              key={index}
              className="bg-white p-8 rounded-xl shadow-lg hover:shadow-2xl transition duration-300 border-t-4 border-yellow-400"
            >
              <div className="text-5xl mb-4">{feature.icon}</div>
              <h3 className="text-2xl font-bold text-blue-900 mb-3">{feature.title}</h3>
              <p className="text-gray-600 leading-relaxed">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
