"use client"

import { useState, useEffect } from "react"
import RegistrationForm from "./registration-form"

export default function Hero() {
  const [timeLeft, setTimeLeft] = useState("23:45")

  useEffect(() => {
    const timer = setInterval(() => {
      const now = new Date()
      const registrationDeadline = new Date("2025-12-15T23:59:59")
      const diff = registrationDeadline - now

      if (diff > 0) {
        const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60))
        const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60))
        setTimeLeft(`${String(hours).padStart(2, "0")}:${String(minutes).padStart(2, "0")}`)
      } else {
        setTimeLeft("00:00")
      }
    }, 1000)

    return () => clearInterval(timer)
  }, [])

  return (
    <section
      id="home"
      className="relative bg-gradient-to-br from-blue-900 via-purple-900 to-indigo-900 text-white overflow-hidden min-h-screen flex items-center"
    >
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute inset-0 bg-[url('/abstract-circuit-pattern.png')] bg-repeat"></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 relative z-10">
        {/* Warning Banner */}
        <div className="bg-red-600 text-white py-2 px-4 rounded mb-8 text-center text-sm font-semibold">
          Warning: Due to extremely high media demand, we will close registration at 12/15/2025 · HURRY {timeLeft}
        </div>

        <div className="grid md:grid-cols-2 gap-12 items-start">
          {/* Left Content - Video/Image Section */}
          <div className="flex flex-col gap-8">
            <div>
              <h1 className="text-5xl md:text-6xl font-bold mb-6 text-balance">
                Bitcoin Is Making People <span className="text-yellow-400">Rich</span>
              </h1>
              <p className="text-xl text-gray-200 mb-8 text-balance">
                And you can become the Next Millionaire...
              </p>
            </div>

            {/* Official Trading Interface Image */}
            <img
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Bitcoin-Era-Review-October-2022%20%281%29-ZEq8K6LMf65phDYUgCqfJLkpiH5Jen.png"
              alt="Bitcoin Era Trading Interface"
              className="w-full rounded-xl shadow-2xl border-4 border-yellow-400"
            />
          </div>

          {/* Right Content - Registration Form */}
          <div className="sticky top-20">
            <RegistrationForm />
          </div>
        </div>
      </div>
    </section>
  )
}
