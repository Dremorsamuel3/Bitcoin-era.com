"use client"

import { useState } from "react"
import Link from "next/link"
import { Menu, X } from "lucide-react"

export default function Navigation() {
  const [isOpen, setIsOpen] = useState(false)

  const toggleMenu = () => setIsOpen(!isOpen)

  return (
    <nav className="bg-gradient-to-r from-blue-900 via-purple-900 to-blue-900 text-white sticky top-0 z-50 shadow-lg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          {/* Logo - CHANGE: Using official Bitcoin Era horizontal logo */}
          <Link href="#home" className="flex items-center gap-2">
            <img src="/images/ab1ec9add86beb20758d0fbd57497064.png" alt="Bitcoin Era" className="h-12 w-auto" />
          </Link>

          {/* Desktop Menu */}
          <div className="hidden md:flex gap-8 items-center">
            <Link href="#home" className="hover:text-yellow-400 transition duration-300">
              Home
            </Link>
            <Link href="#about" className="hover:text-yellow-400 transition duration-300">
              About
            </Link>
            <Link href="#features" className="hover:text-yellow-400 transition duration-300">
              Services
            </Link>
            <Link href="#contact" className="hover:text-yellow-400 transition duration-300">
              Contact
            </Link>
            <button className="bg-yellow-400 text-blue-900 px-6 py-2 rounded-lg font-bold hover:bg-yellow-300 transition duration-300">
              Get Started
            </button>
          </div>

          {/* Mobile Menu Button */}
          <button onClick={toggleMenu} className="md:hidden p-2">
            {isOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Menu */}
        {isOpen && (
          <div className="md:hidden pb-4 space-y-2">
            <Link href="#home" className="block px-4 py-2 hover:bg-blue-800 rounded">
              Home
            </Link>
            <Link href="#about" className="block px-4 py-2 hover:bg-blue-800 rounded">
              About
            </Link>
            <Link href="#features" className="block px-4 py-2 hover:bg-blue-800 rounded">
              Services
            </Link>
            <Link href="#contact" className="block px-4 py-2 hover:bg-blue-800 rounded">
              Contact
            </Link>
            <button className="w-full bg-yellow-400 text-blue-900 px-6 py-2 rounded-lg font-bold hover:bg-yellow-300 transition duration-300">
              Get Started
            </button>
          </div>
        )}
      </div>
    </nav>
  )
}
