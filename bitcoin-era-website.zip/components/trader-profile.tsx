"use client"

export default function TraderProfile() {
  return (
    <section className="py-20 bg-gradient-to-br from-blue-900 via-indigo-900 to-purple-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          {/* Trader Image */}
          <div className="flex justify-center">
            <img
              src="/images/004-e1718021172658.jpeg"
              alt="Professional trader at desk with dual monitors"
              className="w-full rounded-xl shadow-2xl"
            />
          </div>

          {/* Content */}
          <div>
            <h2 className="text-4xl md:text-5xl font-bold mb-6 text-balance">Professional Traders at Your Service</h2>
            <p className="text-lg text-gray-200 mb-6 leading-relaxed">
              Our platform is managed by experienced traders and AI specialists who have spent years perfecting
              automated trading strategies. Every feature is designed to maximize your profits while minimizing risk.
            </p>

            <div className="space-y-4 mb-8">
              {[
                "Real-time market analysis and AI signals",
                "Professional-grade trading tools",
                "24/7 monitoring across all markets",
                "Risk management protocols",
                "Live support from trading experts",
              ].map((item, index) => (
                <div key={index} className="flex items-start gap-3">
                  <span className="text-yellow-400 text-2xl mt-1">✓</span>
                  <p className="text-lg text-gray-100">{item}</p>
                </div>
              ))}
            </div>

            <button className="bg-yellow-400 text-blue-900 px-8 py-4 rounded-lg font-bold text-lg hover:bg-yellow-300 transition duration-300 shadow-lg">
              Join Professional Traders
            </button>
          </div>
        </div>
      </div>
    </section>
  )
}
