"use client"

export default function Trading() {
  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          {/* Image - CHANGE: Using official Bitcoin Era platform screenshot */}
          <div className="flex justify-center">
            <img
              src="/images/bitcoin-era-review-october-2022.png"
              alt="Bitcoin Era Trading"
              className="w-full rounded-xl shadow-2xl"
            />
          </div>

          {/* Content */}
          <div>
            <h2 className="text-4xl md:text-5xl font-bold text-blue-900 mb-6 text-balance">Why Choose Bitcoin Era?</h2>
            <ul className="space-y-4 text-gray-700">
              {[
                "✅ Automated 24/7 trading across all markets",
                "✅ Advanced AI algorithms with 92% accuracy rate",
                "✅ Zero trading experience required",
                "✅ Real-time market analysis and signals",
                "✅ Secure and regulated platform",
                "✅ Multiple payment methods accepted",
                "✅ Dedicated customer support",
                "✅ Low minimum deposit of $250",
              ].map((item, index) => (
                <li key={index} className="text-lg flex items-center gap-3">
                  <span className="text-yellow-400 text-2xl">•</span>
                  {item}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </section>
  )
}
