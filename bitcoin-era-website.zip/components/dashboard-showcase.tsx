"use client"

export default function DashboardShowcase() {
  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-blue-900 mb-4 text-balance">
            Real Trading Results on Your Dashboard
          </h2>
          <p className="text-xl text-gray-600 text-balance">Track your profits, trades, and growth in real-time</p>
        </div>

        {/* Dashboard Screenshot */}
        <div className="rounded-2xl overflow-hidden shadow-2xl mb-12">
          <img src="/images/br6.webp" alt="Bitcoin Revolution trading dashboard with live profits" className="w-full" />
        </div>

        {/* Stats Grid */}
        <div className="grid md:grid-cols-4 gap-6">
          <div className="bg-white p-8 rounded-xl shadow-lg text-center">
            <div className="text-4xl font-bold text-green-500 mb-2">92%</div>
            <p className="text-gray-600 font-semibold">Win Rate</p>
          </div>
          <div className="bg-white p-8 rounded-xl shadow-lg text-center">
            <div className="text-4xl font-bold text-blue-500 mb-2">$1050+</div>
            <p className="text-gray-600 font-semibold">Average Daily Profit</p>
          </div>
          <div className="bg-white p-8 rounded-xl shadow-lg text-center">
            <div className="text-4xl font-bold text-purple-500 mb-2">24/7</div>
            <p className="text-gray-600 font-semibold">Automated Trading</p>
          </div>
          <div className="bg-white p-8 rounded-xl shadow-lg text-center">
            <div className="text-4xl font-bold text-yellow-500 mb-2">$250</div>
            <p className="text-gray-600 font-semibold">Minimum Deposit</p>
          </div>
        </div>
      </div>
    </section>
  )
}
