"use client"

export default function HowItWorks() {
  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-blue-900 mb-4 text-balance">How Does Bitcoin Era Work?</h2>
          <p className="text-xl text-gray-600 text-balance">
            Three simple steps to start your automated trading journey
          </p>
        </div>

        {/* Official How It Works Infographic */}
        <div className="flex justify-center mb-16">
          <img
            src="/images/how-to-trade-with-bitcoin-era.webp"
            alt="How to trade with Bitcoin Era - 3 step process"
            className="w-full max-w-4xl rounded-xl shadow-2xl"
          />
        </div>

        {/* Detailed Steps */}
        <div className="grid md:grid-cols-3 gap-8 mt-12">
          <div className="text-center p-8 bg-gradient-to-br from-purple-50 to-blue-50 rounded-xl shadow-lg hover:shadow-xl transition">
            <div className="text-5xl font-bold text-yellow-400 mb-4">1</div>
            <h3 className="text-2xl font-bold text-blue-900 mb-3">Register Free Account</h3>
            <p className="text-gray-600">
              Create your Bitcoin Era account with just an email address. Takes less than 2 minutes to get started.
            </p>
          </div>

          <div className="text-center p-8 bg-gradient-to-br from-purple-50 to-blue-50 rounded-xl shadow-lg hover:shadow-xl transition">
            <div className="text-5xl font-bold text-yellow-400 mb-4">2</div>
            <h3 className="text-2xl font-bold text-blue-900 mb-3">Fund Your Account</h3>
            <p className="text-gray-600">
              Deposit funds starting from just $250. We handle all transactions through regulated brokers securely.
            </p>
          </div>

          <div className="text-center p-8 bg-gradient-to-br from-purple-50 to-blue-50 rounded-xl shadow-lg hover:shadow-xl transition">
            <div className="text-5xl font-bold text-yellow-400 mb-4">3</div>
            <h3 className="text-2xl font-bold text-blue-900 mb-3">Start Trading</h3>
            <p className="text-gray-600">
              Our AI robots handle everything automatically. Watch your profits grow 24/7 while you relax.
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}
