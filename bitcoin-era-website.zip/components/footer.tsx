"use client"

export default function Footer() {
  return (
    <footer className="bg-blue-900 text-white py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-4 gap-8 mb-8">
          {/* Company - CHANGE: Using official Bitcoin Era logo */}
          <div>
            <img src="/images/bitcoin-era-dxz-logo.webp" alt="Bitcoin Era Logo" className="h-12 w-auto mb-4" />
            <p className="text-gray-300">Automated AI trading for Forex, Stocks, Crypto, Indices & Metals</p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-bold text-lg mb-4">Quick Links</h4>
            <ul className="space-y-2 text-gray-300">
              <li>
                <a href="#home" className="hover:text-yellow-400">
                  Home
                </a>
              </li>
              <li>
                <a href="#about" className="hover:text-yellow-400">
                  About
                </a>
              </li>
              <li>
                <a href="#features" className="hover:text-yellow-400">
                  Services
                </a>
              </li>
              <li>
                <a href="#contact" className="hover:text-yellow-400">
                  Contact
                </a>
              </li>
            </ul>
          </div>

          {/* Legal */}
          <div>
            <h4 className="font-bold text-lg mb-4">Legal</h4>
            <ul className="space-y-2 text-gray-300">
              <li>
                <a href="#" className="hover:text-yellow-400">
                  Privacy Policy
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-yellow-400">
                  Terms of Service
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-yellow-400">
                  Risk Disclosure
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-yellow-400">
                  Disclaimer
                </a>
              </li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="font-bold text-lg mb-4">Contact</h4>
            <ul className="space-y-2 text-gray-300">
              <li>📧 support@bitcoinera.com</li>
              <li>📞 +1-800-BITCOIN</li>
              <li>🕐 24/7 Customer Support</li>
              <li>🌍 Worldwide Service</li>
            </ul>
          </div>
        </div>

        {/* Divider */}
        <div className="border-t border-gray-700 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400">&copy; 2025 Bitcoin Era. All rights reserved.</p>
            <div className="flex gap-6 mt-4 md:mt-0">
              <a href="#" className="text-gray-400 hover:text-yellow-400">
                Facebook
              </a>
              <a href="#" className="text-gray-400 hover:text-yellow-400">
                Twitter
              </a>
              <a href="#" className="text-gray-400 hover:text-yellow-400">
                LinkedIn
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}
