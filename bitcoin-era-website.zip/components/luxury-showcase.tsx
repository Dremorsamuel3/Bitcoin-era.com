"use client"

export default function LuxuryShowcase() {
  return (
    <section className="py-20 bg-gradient-to-b from-purple-900 to-blue-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4 text-balance">Success Comes with Bitcoin Era</h2>
          <p className="text-xl text-gray-200 text-balance">
            From luxury cars to financial freedom - your dreams are within reach
          </p>
        </div>

        {/* Top Featured - Pink Rolls Royce */}
        <div className="mb-16 rounded-2xl overflow-hidden shadow-2xl">
          <img
            src="/images/untitled-design-2025-11.jpg"
            alt="Hot pink Rolls Royce luxury SUV"
            className="w-full h-96 object-cover"
          />
        </div>

        {/* Two Column Layout */}
        <div className="grid md:grid-cols-2 gap-12 items-center mb-16">
          {/* Left - Yellow Lamborghini */}
          <div className="rounded-2xl overflow-hidden shadow-2xl">
            <img
              src="/images/lamborghinimanifesto6-e1759847190669.png"
              alt="Yellow Lamborghini manifesto supercar"
              className="w-full"
            />
          </div>

          {/* Right - Text Content */}
          <div>
            <h3 className="text-4xl font-bold mb-6">Transform Your Life Today</h3>
            <p className="text-xl text-gray-200 mb-6 leading-relaxed">
              Thousands of traders have already transformed their lives with Bitcoin Era's automated trading system.
              From luxury supercars to financial independence, your success story starts here.
            </p>
            <ul className="space-y-4 mb-8">
              {[
                "Turn $250 into consistent passive income",
                "Trade 24/7 automatically while you enjoy life",
                "92% accuracy rate with advanced AI technology",
                "Join thousands of elite Bitcoin Era traders worldwide",
                "Achieve the luxury lifestyle you've always dreamed of",
              ].map((item, index) => (
                <li key={index} className="flex items-center gap-3 text-lg">
                  <span className="w-3 h-3 bg-yellow-400 rounded-full flex-shrink-0"></span>
                  {item}
                </li>
              ))}
            </ul>
            <button className="bg-yellow-400 text-blue-900 px-8 py-4 rounded-lg font-bold text-lg hover:bg-yellow-300 transition duration-300 shadow-lg">
              Start Your Success Story Now
            </button>
          </div>
        </div>
      </div>
    </section>
  )
}
