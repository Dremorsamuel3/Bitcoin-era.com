"use client"

export default function WealthSection() {
  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-blue-900 mb-4 text-balance">The Wealth You Deserve</h2>
          <p className="text-xl text-gray-600 text-balance">See what successful Bitcoin Era traders have achieved</p>
        </div>

        <div className="grid md:grid-cols-4 gap-8">
          {/* Bugatti La Voiture Noire */}
          <div className="rounded-xl overflow-hidden shadow-2xl hover:shadow-3xl transition duration-300">
            <img
              src="/images/bugatti-la-voiture-noire-01-lvn-34-front-956994.jpg"
              alt="Bugatti La Voiture Noire luxury hypercar"
              className="w-full h-64 object-cover"
            />
            <div className="bg-blue-900 text-white p-6">
              <h3 className="text-xl font-bold mb-2">Hypercar Dreams</h3>
              <p className="text-sm text-gray-200">Achieve your ultimate luxury vehicle dreams</p>
            </div>
          </div>

          {/* White & Gold Bugatti */}
          <div className="rounded-xl overflow-hidden shadow-2xl hover:shadow-3xl transition duration-300">
            <img
              src="/images/car-768x432.jpg"
              alt="White and gold Bugatti luxury sports car"
              className="w-full h-64 object-cover"
            />
            <div className="bg-blue-900 text-white p-6">
              <h3 className="text-xl font-bold mb-2">Premium Lifestyle</h3>
              <p className="text-sm text-gray-200">Live the elite luxury experience</p>
            </div>
          </div>

          {/* Purple Neon Car */}
          <div className="rounded-xl overflow-hidden shadow-2xl hover:shadow-3xl transition duration-300">
            <img
              src="/images/images-20-202025-08.jpeg"
              alt="Purple neon futuristic sports car"
              className="w-full h-64 object-cover"
            />
            <div className="bg-blue-900 text-white p-6">
              <h3 className="text-xl font-bold mb-2">Future Tech</h3>
              <p className="text-sm text-gray-200">Next-generation luxury vehicles</p>
            </div>
          </div>

          {/* Technology Database */}
          <div className="rounded-xl overflow-hidden shadow-2xl hover:shadow-3xl transition duration-300">
            <img
              src="/images/join-ico-2.webp"
              alt="Advanced technology database system"
              className="w-full h-64 object-cover"
            />
            <div className="bg-blue-900 text-white p-6">
              <h3 className="text-xl font-bold mb-2">Smart Technology</h3>
              <p className="text-sm text-gray-200">AI-powered automated trading system</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
