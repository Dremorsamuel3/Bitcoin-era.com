"use client"

export default function Testimonials() {
  const testimonials = [
    {
      name: "Dremor Samuel",
      amount: "UGX 18,280,000",
      text: "Bitcoin Era changed my financial life. I started with UGX 1.5M and now I am earning over UGX 8M weekly!",
      image: "👨‍💼",
    },
    {
      name: "Basoga Patrick",
      amount: "UGX 25,640,000",
      text: "The automated trading system is incredible. No experience needed. I am making more than my day job!",
      image: "👨‍💼",
    },
    {
      name: "Kyagulanyi Ssentamu",
      amount: "UGX 32,450,000",
      text: "Best investment I ever made. The AI robot trades while I sleep. Highly recommended!",
      image: "👨‍💼",
    },
    {
      name: "Nakamatte Grace",
      amount: "UGX 21,350,000",
      text: "Started trading 3 months ago. Now my family is living comfortably. Thank you Bitcoin Era!",
      image: "👩‍💼",
    },
    {
      name: "Obbo Richard",
      amount: "UGX 28,900,000",
      text: "I never thought passive income was possible. Now I earn daily without any effort!",
      image: "👨‍💼",
    },
    {
      name: "Nakabugo Stella",
      amount: "UGX 19,750,000",
      text: "The customer support is amazing. They helped me set up and now I'm a successful trader!",
      image: "👩‍💼",
    },
  ]

  return (
    <section className="py-20 bg-gradient-to-r from-blue-900 via-purple-900 to-blue-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4 text-balance">Real Results from Real Traders</h2>
          <p className="text-xl text-gray-200 text-balance">
            Join thousands of successful Ugandan traders making passive income
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div key={index} className="bg-white/10 backdrop-blur-sm p-8 rounded-xl border border-yellow-400/30">
              <div className="text-6xl mb-4">{testimonial.image}</div>
              <h3 className="text-2xl font-bold mb-2">{testimonial.name}</h3>
              <p className="text-yellow-400 text-lg font-bold mb-4">{testimonial.amount}</p>
              <p className="text-gray-200 leading-relaxed italic">"{testimonial.text}"</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
