"use client"

import { useState } from "react"
import { Eye, EyeOff, CheckCircle, AlertCircle } from 'lucide-react'

export default function RegistrationForm() {
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    password: "",
    country: "",
    phoneCode: "+1",
    phone: "",
  })

  const [showPassword, setShowPassword] = useState(false)
  const [isSubmitted, setIsSubmitted] = useState(false)
  const [errors, setErrors] = useState<Record<string, string>>({})

  const validateForm = () => {
    const newErrors: Record<string, string> = {}
    
    if (!formData.firstName.trim()) newErrors.firstName = "First name is required"
    if (!formData.lastName.trim()) newErrors.lastName = "Last name is required"
    if (!formData.email.trim()) newErrors.email = "Email is required"
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) newErrors.email = "Invalid email format"
    if (!formData.password) newErrors.password = "Password is required"
    else if (formData.password.length < 6) newErrors.password = "Password must be at least 6 characters"
    if (!formData.country.trim()) newErrors.country = "Country is required"
    if (!formData.phone.trim()) newErrors.phone = "Phone number is required"

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }))
    if (errors[name]) {
      setErrors((prev) => ({
        ...prev,
        [name]: "",
      }))
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    
    if (validateForm()) {
      console.log("[v0] Registration submitted:", formData)
      setIsSubmitted(true)
      
      setTimeout(() => {
        setFormData({
          firstName: "",
          lastName: "",
          email: "",
          password: "",
          country: "",
          phoneCode: "+1",
          phone: "",
        })
        setIsSubmitted(false)
      }, 3000)
    }
  }

  if (isSubmitted) {
    return (
      <div className="bg-gradient-to-br from-yellow-400 to-orange-400 rounded-xl p-8 shadow-2xl">
        <div className="flex flex-col items-center text-center space-y-4">
          <CheckCircle size={56} className="text-green-600" />
          <h3 className="text-2xl font-bold text-blue-900">Registration Successful!</h3>
          <p className="text-blue-800 font-medium">Welcome to Bitcoin Era</p>
          <p className="text-sm text-blue-900">
            Confirmation email sent to <span className="font-bold">{formData.email}</span>
          </p>
        </div>
      </div>
    )
  }

  return (
    <div className="bg-gradient-to-br from-yellow-400 to-orange-400 rounded-xl p-8 shadow-2xl">
      <div className="mb-6">
        <h3 className="text-2xl font-bold text-blue-900 mb-2 text-center">START A NEW LIFE TODAY AND</h3>
        <h4 className="text-xl font-bold text-blue-900 mb-3 text-center">GAIN FINANCIAL FREEDOM</h4>
      </div>
      
      <form onSubmit={handleSubmit} className="space-y-4">
        
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-sm font-semibold text-blue-900 mb-2">First Name *</label>
            <input
              type="text"
              name="firstName"
              placeholder="First Name"
              value={formData.firstName}
              onChange={handleChange}
              className={`w-full px-4 py-2 rounded border-2 ${
                errors.firstName ? "border-red-500 bg-red-50" : "border-transparent"
              } focus:outline-none focus:border-blue-900 bg-white transition`}
            />
            {errors.firstName && (
              <div className="flex items-center gap-1 text-red-600 text-xs mt-1">
                <AlertCircle size={14} />
                {errors.firstName}
              </div>
            )}
          </div>
          <div>
            <label className="block text-sm font-semibold text-blue-900 mb-2">Last Name *</label>
            <input
              type="text"
              name="lastName"
              placeholder="Last Name"
              value={formData.lastName}
              onChange={handleChange}
              className={`w-full px-4 py-2 rounded border-2 ${
                errors.lastName ? "border-red-500 bg-red-50" : "border-transparent"
              } focus:outline-none focus:border-blue-900 bg-white transition`}
            />
            {errors.lastName && (
              <div className="flex items-center gap-1 text-red-600 text-xs mt-1">
                <AlertCircle size={14} />
                {errors.lastName}
              </div>
            )}
          </div>
        </div>

        <div>
          <label className="block text-sm font-semibold text-blue-900 mb-2">Email Address *</label>
          <input
            type="email"
            name="email"
            placeholder="your.email@example.com"
            value={formData.email}
            onChange={handleChange}
            className={`w-full px-4 py-2 rounded border-2 ${
              errors.email ? "border-red-500 bg-red-50" : "border-transparent"
            } focus:outline-none focus:border-blue-900 bg-white transition`}
          />
          {errors.email && (
            <div className="flex items-center gap-1 text-red-600 text-xs mt-1">
              <AlertCircle size={14} />
              {errors.email}
            </div>
          )}
        </div>

        <div>
          <label className="block text-sm font-semibold text-blue-900 mb-2">Password *</label>
          <div className="relative">
            <input
              type={showPassword ? "text" : "password"}
              name="password"
              placeholder="Enter a secure password"
              value={formData.password}
              onChange={handleChange}
              className={`w-full px-4 py-2 pr-10 rounded border-2 ${
                errors.password ? "border-red-500 bg-red-50" : "border-transparent"
              } focus:outline-none focus:border-blue-900 bg-white transition`}
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-3 top-2.5 text-gray-500 hover:text-gray-700"
            >
              {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
            </button>
          </div>
          {errors.password && (
            <div className="flex items-center gap-1 text-red-600 text-xs mt-1">
              <AlertCircle size={14} />
              {errors.password}
            </div>
          )}
        </div>

        <div>
          <label className="block text-sm font-semibold text-blue-900 mb-2">Country *</label>
          <select
            name="country"
            value={formData.country}
            onChange={handleChange}
            className={`w-full px-4 py-2 rounded border-2 ${
              errors.country ? "border-red-500 bg-red-50" : "border-transparent"
            } focus:outline-none focus:border-blue-900 bg-white transition`}
          >
            <option value="">-- Select Your Country --</option>
            <option value="Canada">🇨🇦 Canada</option>
            <option value="United States">🇺🇸 United States</option>
            <option value="United Kingdom">🇬🇧 United Kingdom</option>
            <option value="Australia">🇦🇺 Australia</option>
            <option value="Germany">🇩🇪 Germany</option>
            <option value="France">🇫🇷 France</option>
            <option value="Other">🌍 Other</option>
          </select>
          {errors.country && (
            <div className="flex items-center gap-1 text-red-600 text-xs mt-1">
              <AlertCircle size={14} />
              {errors.country}
            </div>
          )}
        </div>

        <div>
          <label className="block text-sm font-semibold text-blue-900 mb-2">Phone Number *</label>
          <div className="flex gap-2">
            <select
              name="phoneCode"
              value={formData.phoneCode}
              onChange={handleChange}
              className="w-24 px-3 py-2 rounded border-2 border-transparent focus:outline-none focus:border-blue-900 bg-white transition"
            >
              <option value="+1">+1</option>
              <option value="+44">+44</option>
              <option value="+61">+61</option>
              <option value="+49">+49</option>
              <option value="+33">+33</option>
            </select>
            <input
              type="tel"
              name="phone"
              placeholder="(123) 456-7890"
              value={formData.phone}
              onChange={handleChange}
              className={`flex-1 px-4 py-2 rounded border-2 ${
                errors.phone ? "border-red-500 bg-red-50" : "border-transparent"
              } focus:outline-none focus:border-blue-900 bg-white transition`}
            />
          </div>
          {errors.phone && (
            <div className="flex items-center gap-1 text-red-600 text-xs mt-1">
              <AlertCircle size={14} />
              {errors.phone}
            </div>
          )}
        </div>

        <button
          type="submit"
          className="w-full bg-blue-900 text-white font-bold py-3 rounded-lg hover:bg-blue-800 transition duration-300 text-lg mt-6 shadow-lg hover:shadow-xl"
        >
          GET STARTED NOW!
        </button>

        <div className="bg-blue-50 p-3 rounded-lg border border-blue-200 text-center">
          <p className="text-xs text-blue-900">
            ✓ Secure & Encrypted | ✓ Regulated Platform
          </p>
        </div>
      </form>
    </div>
  )
}
